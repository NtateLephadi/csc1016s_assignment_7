/**
 * Public interface MakesSound can be implemented to create different sounds
 * @author Tumelo Lephadi
 * @version 18/09/2015
 */
 
public interface MakesSound
{
   public String makeNoise() ;
}