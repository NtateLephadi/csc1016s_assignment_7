/**
 * Class Cow implements MakesSound interface and returns Moo!.
 * @author Tumelo Lephadi
 * @version 18/09/2015 
 */

public class Cow implements MakesSound
{
   public String makeNoise()
   {
      return "Moo!" ;
   }
}